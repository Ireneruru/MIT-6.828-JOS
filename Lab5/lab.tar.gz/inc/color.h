int FG_COLOR;
int BG_COLOR;
int COLOR;
